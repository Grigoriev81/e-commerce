<?php
// Heading
$_['heading_title']      = 'Бонусные баллы';

// Column
$_['column_date_added']  = 'Дата начисления';
$_['column_description'] = 'Начислены за:';
$_['column_points']      = 'Всего Баллов';

// Text
$_['text_account']       = 'Личный кабинет';
$_['text_reward']        = 'Бонусные баллы';
$_['text_total']         = 'Накоплено бонусных баллов:';
$_['text_empty']         = 'У вас нет бонусных балов!';
