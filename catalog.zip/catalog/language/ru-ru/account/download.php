<?php
// Heading
$_['heading_title']   = 'Файлы для скачивания';

// Text
$_['text_account']    = 'Личный кабинет';
$_['text_downloads']  = 'Файлы для скачивания';
$_['text_empty']        = 'У вас не было заказов с файлами для скачивания!';

// Column
$_['column_order_id']   = '№ заказа:';
$_['column_name']       = 'Имя:';
$_['column_size']       = 'Размер:';
$_['column_date_added'] = 'Дата добавления:';
