<?php
// Text
$_['text_title'] = 'Оплата при получении';