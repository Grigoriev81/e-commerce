<?php
// Heading
$_['heading_title'] = 'Хиты продаж';

// Text
$_['text_tax']      = 'Без налога:';