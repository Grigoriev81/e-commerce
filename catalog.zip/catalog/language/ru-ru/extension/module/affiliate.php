<?php
// Heading
$_['heading_title']    = 'Кабинета партнера';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Авторизация';
$_['text_logout']      = 'Выйти';
$_['text_forgotten']   = 'Напомнить пароль';
$_['text_account']     = 'Личный кабинет';
$_['text_edit']        = 'Данные учетной записи';
$_['text_password']    = 'Смена пароля';
$_['text_payment']     = 'Способ оплаты';
$_['text_tracking']    = 'Рефералы партнера';
$_['text_transaction'] = 'История выплат';
