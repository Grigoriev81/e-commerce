<?php
// Heading
$_['heading_title'] = 'Выберите магазин';

// Text
$_['text_default']  = 'По умолчанию';
$_['text_store']    = 'Выберите магазин, который хотите посетить.';