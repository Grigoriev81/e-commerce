<?php
// Text
$_['text_all_reviews']  = 'Все отзывы о товарах';