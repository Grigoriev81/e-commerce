<?php
// Heading
$_['heading_title'] = 'Товары со скидкой';

// Text
$_['text_tax']      = 'Без налога:';