<?php
// Text
$_['text_search'] = 'Поиск товара по каталогу';