<?php
// Text
$_['text_items']     = '%s товар(ов) - %s';
$_['text_empty']     = 'В корзине пусто!';
$_['text_cart']      = 'Открыть корзину';
$_['text_checkout']  = 'Оформить заказ';
$_['text_recurring'] = 'Профиль платежа';
