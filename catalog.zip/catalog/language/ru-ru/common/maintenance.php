<?php
// Heading
$_['heading_title']    = 'Режим обслуживания';

// Text
$_['text_maintenance'] = 'Режим обслуживания';
$_['text_message']     = '<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><h1 style="text-align:center;">В настоящее время магазин закрыт на техническое обслуживание. <br/>Пожалуйста, зайдите чуть позже!</h1><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>';