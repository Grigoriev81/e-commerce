<?php
// Text
$_['text_information']  = 'Информация';
$_['text_service']      = 'Служба поддержки';
$_['text_extra']        = 'Дополнительно';
$_['text_contact']      = 'Связаться с нами';
$_['text_return']       = 'Возврат товара';
$_['text_sitemap']      = 'Карта сайта';
$_['text_manufacturer'] = 'Производители';
$_['text_voucher']      = 'Подарочные сертификаты';
$_['text_affiliate']    = 'Партнёры';
$_['text_special']      = 'Товары со скидкой';
$_['text_account']      = 'Личный кабинет';
$_['text_order']        = 'История заказов';
$_['text_wishlist']     = 'Мои закладки';
$_['text_newsletter']   = 'Рассылка новостей';
$_['text_powered']      = 'Работает на <a target="_blank" href="https://ocstore.com/?utm_source=ocstore23">ocStore</a><br /> %s &copy; %s';
