<?php
// Text
$_['text_all_reviews']  = 'Show all reviews';