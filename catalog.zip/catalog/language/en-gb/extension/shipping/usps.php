<?php
// Text
$_['text_title']  = 'United States Postal Service';
$_['text_weight'] = 'Weight:';
$_['text_eta']    = 'Estimated Time:';