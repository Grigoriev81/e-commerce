<?php
// Text
$_['text_title']				= '<img  src="image/payment/new_post_out.png" alt="Новая почта" title="Новая почта" /> Наложенный платёж';
$_['text_instruction']			= 'Инструкции по наложеному платежу';
$_['text_description']			= 'Пожалуйста, следуйте инструкциям.';
$_['text_payment']				= 'Ваш заказ будет сформирован и отправлен наложенным платежом.';