<?php
// Text
$_['text_title'] 				= 'Online payment Wayforpay';
$_['text_success'] 				= 'Failed payment';
$_['text_basket'] 				= 'Cart';
$_['text_checkout'] 			= 'Checkout';
$_['text_message'] 				= 'Order payment failed. Perhaps there are not enough funds or you made a mistake when entering the details. Try again...';

$_['heading_title_wtf_fail'] 	= 'Failed payment';