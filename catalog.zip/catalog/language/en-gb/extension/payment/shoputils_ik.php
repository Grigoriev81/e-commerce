<?php
// Text
$_['text_ik_payment_desc']        = 'Оплата заказа №%s';

$_['text_comment']                = 'Интеркасса: %s. Сумма: %s.';
$_['text_comment_fail']           = 'Интеркасса: оплата не удалась.';
$_['text_description']            = 'Возможные методы оплаты: <br/><img src="%scatalog/view/theme/default/image/shoputils_ik.png" alt="Методы оплаты" />';

$_['text_error_allowed_range_ip'] = 'Удаленный IP шлюза %s не из разрешенного диапазона';
$_['text_error_post']             = 'Ответ от шлюза не типа POST';
$_['text_error_ik_sign_hash']     = 'Некорректная подпись сообщения от платёжного шлюза';
$_['text_error_order_not_found']  = 'Заказ № "%s" не найден';
?>