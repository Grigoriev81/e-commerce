<?php
final class Smsc extends SmsGate {

	public function send() {
		return $this->_read_url('http://smsc.ru/sys/send.php?login='.urlencode($this->username).'&psw='.md5($this->password).
							'&phones='.urlencode($this->to.($this->copy ? ','.$this->copy : '')).'&mes='.urlencode($this->message).
							'&sender='.urlencode($this->from).'&cost=3&fmt=1&charset=utf8');
	}

	// ������� ������ URL. ��� ������ ������ ���� ��������:
	// curl ��� fsockopen (������ http) ��� �������� ����� allow_url_fopen ��� file_get_contents

	private function _read_url($url)
	{
		$ret = "";

		if (function_exists("curl_init"))
		{
			static $c = 0; // keepalive

			if (!$c) {
				$c = curl_init();
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 10);
				curl_setopt($c, CURLOPT_TIMEOUT, 10);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
			}

			curl_setopt($c, CURLOPT_URL, $url);

			$ret = curl_exec($c);
		}
		elseif (function_exists("fsockopen") && strncmp($url, 'http:', 5) == 0) // not https
		{
			$m = parse_url($url);

			$fp = fsockopen($m["host"], 80, $errno, $errstr, 10);

			if ($fp) {
				fwrite($fp, "GET $m[path]?$m[query] HTTP/1.1\r\nHost: smsc.ru\r\nUser-Agent: PHP\r\nConnection: Close\r\n\r\n");

				while (!feof($fp))
					$ret = fgets($fp, 1024);

				fclose($fp);
			}
		}
		else
			$ret = file_get_contents($url);

		return $ret;
	}
}
?>