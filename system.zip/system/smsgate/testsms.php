<?php
final class TestSms extends SmsGate { }
?>