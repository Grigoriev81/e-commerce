<?php
// Heading
$_['heading_title']		 = 'Наложенный платёж';

// Text
$_['text_extension']	 = 'Платежи';
$_['text_success']		 = 'Настройки модуля успешно обновлены!';
$_['text_new_post_out']  = '<a href="https://novaposhta.ua/" onclick="return !window.open(this.href)"><img  src="view/image/payment/new_post_out.png" alt="Новая почта" title="Новая почта" /></a>';
$_['text_edit']          = 'Редактирование модуля';

// Entry
$_['entry_np_send']		 = 'Инструкция по платежу:';
$_['entry_total']		 = 'Минимальная сумма:';
$_['entry_order_status'] = 'Статус заказа после оформления заказа:';
$_['entry_geo_zone']	 = 'Географическая зона:';
$_['entry_status']		 = 'Статус:';
$_['entry_sort_order']	 = 'Порядок сортировки:';

// Help
$_['help_total']		 = 'Ниже этой суммы метод будет недоступен.';

// Error
$_['error_permission']   = 'У вас нет прав для управления этим модулем!';
$_['error_np_send']         = 'Необходимо указать инструкцию по наложеному платежу!';
